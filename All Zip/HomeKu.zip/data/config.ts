export const siteConfig = {
  name: "HomeKu",
  tagline: "Modern Heritage Living",
  whatsappNumber: "6212345678", //Format KodeNegara + Nomor
  email: "contact@gmail.com",
  instagram: "https://isntagram.com/homeku",
  footerCopyright: "© 2026 HOMEKU COLLECTIVE",
  footerSubject: "ARCHITECTURE FOR THE ANTHROPOCENE"
};